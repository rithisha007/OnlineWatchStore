import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Sonata',
  templateUrl: './Sonata.component.html',
  styleUrls: ['./Sonata.component.css']
})
export class SonataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
