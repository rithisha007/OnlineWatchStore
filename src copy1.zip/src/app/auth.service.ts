import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class Authservice {
  private loggedInUserKey = 'loggedInUser'; // Key for storing the logged-in user in local storage
  private adminEmail = 'Admin007@gmail.com';
  setUser: any;
  constructor(private http: HttpClient){}

  login(user: any) {
    localStorage.setItem(this.loggedInUserKey, JSON.stringify(user)); // Store the user data in local storage
  }

  logout() {
    localStorage.removeItem(this.loggedInUserKey); // Clear the user data from local storage
  }

  getLoggedInUser() {
    const user = localStorage.getItem(this.loggedInUserKey);
    return user ? JSON.parse(user) : null;
  }

  isLoggedIn() {
    return !!localStorage.getItem(this.loggedInUserKey);
  }
 getUserEmail() {
    const user = this.getLoggedInUser();
    return user ? user.email : null;
  }
  isAuthenticated() {
    return this.isLoggedIn(); // Invoke the isLoggedIn function to return its result
  }
  
getUserId(): number {
  const user = this.getLoggedInUser();
  return user ? user.id : null;
}


getUserDetails(userEmail: string): Observable<any[]> {
  return this.http.get<any[]>('http://localhost:3000/signup?email=' + userEmail);
}


isUserAdmin() {
  const email = this.getUserEmail();
  return email === this.adminEmail;
}


}

