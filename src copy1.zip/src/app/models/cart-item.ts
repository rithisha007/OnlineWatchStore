export interface CartItem {
    title: string;
    price: number;
    quantity: number;
    fullPrice: number;
    description: string;
    thumbnail:string;
    imageUrl: string; 
  }
  