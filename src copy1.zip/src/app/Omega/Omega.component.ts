import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Omega',
  templateUrl: './Omega.component.html',
  styleUrls: ['./Omega.component.css']
})
export class OmegaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
