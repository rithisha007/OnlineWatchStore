import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Kids',
  templateUrl: './Kids.component.html',
  styleUrls: ['./Kids.component.css']
})
export class KidsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
