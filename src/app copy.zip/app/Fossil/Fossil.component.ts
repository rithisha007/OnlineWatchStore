import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Fossil',
  templateUrl: './Fossil.component.html',
  styleUrls: ['./Fossil.component.css']
})
export class FossilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
