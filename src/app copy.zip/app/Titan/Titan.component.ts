import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Titan',
  templateUrl: './Titan.component.html',
  styleUrls: ['./Titan.component.css']
})
export class TitanComponent implements OnInit {

  image1:string;
  image2:string;
  image3:string;
  image4:string;
  image5:string;
  image6:string;
  image7:string;
  image8:string;
  image9:string;
  image10:string;
  image11:string;
  image12:string;
  image13:string;
  image14:string;
  image15:string;
  image16:string;
  image17:string;
  image18:string;
  image19:string;
  image20:string;

  constructor() {

    this.image1='/assets/images/titan1.webp';

    this.image2='/assets/images/titan2.webp';

    this.image3='/assets/images/titan3.webp';

    this.image4='/assets/images/titan4.webp';

    this.image5='/assets/images/titan5.webp';

    this.image6='/assets/images/titan6.webp';

    this.image7='/assets/images/titan7.webp';

    this.image8='/assets/images/titan8.webp';

    this.image9='/assets/images/titan9.webp';

    this.image10='/assets/images/titan10.webp';

    this.image11='/assets/images/titan11.webp';

    this.image12='/assets/images/titan12.webp';

    this.image13='/assets/images/titan13.webp';

    this.image14='/assets/images/titan14.webp';

    this.image15='/assets/images/titan15.webp';

    this.image16='/assets/images/titan16.webp';

    this.image17='/assets/images/titan17.webp';

    this.image18='/assets/images/titan18.webp';

    this.image19='/assets/images/titan19.webp';

    this.image20='/assets/images/titan20.webp';



    



   }

  ngOnInit() {
  }

}
