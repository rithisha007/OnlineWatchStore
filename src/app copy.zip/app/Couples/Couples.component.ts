import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Couples',
  templateUrl: './Couples.component.html',
  styleUrls: ['./Couples.component.css']
})
export class CouplesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
