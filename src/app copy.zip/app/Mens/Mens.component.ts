import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Mens',
  templateUrl: './Mens.component.html',
  styleUrls: ['./Mens.component.css']
})
export class MensComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
