import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Fastrack',
  templateUrl: './Fastrack.component.html',
  styleUrls: ['./Fastrack.component.css']
})
export class FastrackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
